# NexaCore Growth Coach

Fully local AI-powered performance management.
No cloud APIs. No API keys. All data stays on your machine.

## What it does
- SMART calibration grounded in live OKRs + your company policy docs
- Feedback synthesis with bias detection per policy standards
- Growth coaching that cites actual policy sections
- Policy document management — upload Word docs, indexed instantly
- Dynamic OKR management via UI
- Org structure managed in DB — add/edit departments and roles live
- Employee data from HRIS CSV

## Setup

### 1. Install Ollama (required for AI features)

  Download and install from https://ollama.com/download (macOS app).

  After install:
  1. Open **Ollama** from Applications (keeps the server running in the menu bar)
  2. Pull the model:

  ```bash
  ollama pull llama3.1
  ```

  Verify it works:

  ```bash
  curl http://localhost:11434/api/tags
  ```

  You should see `llama3.1` in the models list.

### 2. Add your files (both optional)
  Employee CSV  → backend/data/employees.csv
  Policy docs   → backend/data/policies/*.docx
  (auto-ingested on first backend startup)

### 3. Backend

  Requires **Python 3.10–3.12** (3.12 recommended). Python 3.14 is not supported.

  cd backend
  cp .env.example .env

  # Create and activate a virtual environment
  python3.12 -m venv .venv          # use python3.12 if installed
  source .venv/bin/activate         # macOS / Linux
  # .venv\Scripts\activate          # Windows

  pip install --upgrade pip
  pip install -r requirements.txt
  uvicorn main:app --reload --port 8000

  If Python 3.12 is not installed, use uv to install it locally (no admin needed):

  curl -LsSf https://astral.sh/uv/install.sh | sh
  source "$HOME/.local/bin/env"
  UV_SYSTEM_CERTS=1 uv python install 3.12
  UV_SYSTEM_CERTS=1 uv venv .venv --python 3.12
  source .venv/bin/activate
  UV_SYSTEM_CERTS=1 uv pip install -r requirements.txt

  First run output:
    Employees ingested: 25
    OKRs seeded: 6
    Org nodes seeded: 186
    OKR embeddings synced: 6
    Policy documents auto-ingested: 2
    Policy chunks indexed: 148

### 4. Frontend

  cd frontend && npm install && npm run dev

  If `npm` is not found, Node is likely installed via nvm but not loaded. Either:

  ```bash
  source ~/.zshrc          # reload shell (nvm added to .zshrc)
  cd frontend && npm run dev
  ```

  Or use the helper script (loads nvm automatically):

  ```bash
  cd frontend && ./run-dev.sh
  ```

  Don't have Node at all? Install nvm then Node:

  ```bash
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
  source ~/.zshrc
  nvm install --lts
  cd frontend && npm install && npm run dev
  ```

### 5. Open  http://localhost:5173

## Adding more policy documents after first run
  Option A: Drop .docx files into backend/data/policies/
            and restart the backend (auto-ingested)
  Option B: Use the Policy Documents panel in the UI
            to upload directly (no restart needed)

## Switching the LLM

  Edit backend/.env, change the model name, pull it, restart backend:

  ```bash
  ollama pull phi3:mini
  ```

  ```env
  OLLAMA_MODEL=phi3:mini
  ```

  Good lightweight options (smaller download, faster, less RAM):

  | Model | Size | Notes |
  |-------|------|-------|
  | `phi3:mini` | ~2.3 GB | Strong for its size; good default if llama3.1 is too heavy |
  | `llama3.2:3b` | ~2 GB | Fast, decent instruction following |
  | `llama3.2:1b` | ~1.3 GB | Smallest; OK for coach chat, JSON may be less reliable |
  | `gemma2:2b` | ~1.6 GB | Small Google model |
  | `mistral` | ~4 GB | README default alternative; balanced |
  | `llama3.1` | ~4.7 GB | Best quality; default in this project |

  Browse all models: https://ollama.com/library

  After changing `.env`, restart the backend. The Dashboard shows whether Ollama is running and the model is loaded.

## How policy documents are used
  Every agent call retrieves the 3 most relevant policy chunks
  via semantic search before building its prompt.
  The calibrator cites policy sections in its response.
  The coach references policy when directly relevant.
  The synthesiser applies policy bias standards.

## Troubleshooting `pip install`

### `pydantic-core` / SSL / Rust build errors (Python 3.14)

**Cause:** The pinned `pydantic==2.7.1` has no pre-built wheel for Python 3.14,
so pip tries to compile from source, download Rust, and fails with:
`SSL: CERTIFICATE_VERIFY_FAILED`.

**Fix (recommended):** Use the updated requirements (allows pydantic 2.10+ with 3.14 wheels):

```bash
cd backend
source .venv/bin/activate
pip install --upgrade pip certifi
pip install -r requirements.txt
```

**Alternative:** Install Python 3.12 from https://www.python.org/downloads/ and recreate the venv:

```bash
rm -rf .venv
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**macOS SSL fix** (if other packages fail to download): run the certificate installer
that ships with python.org Python:

```bash
open "/Applications/Python 3.14/Install Certificates.command"
```

Then retry `pip install -r requirements.txt`.

### Hugging Face 403 / `cas-server.xethub.hf.co` error on startup

**Cause:** Hugging Face's xet download path fails with 403 when downloading the
embedding model (`all-MiniLM-L6-v2`).

**Fix:** Already set in `.env.example` — ensure your `.env` includes:

```
HF_HUB_DISABLE_XET=1
```

Then restart the backend. The model downloads via the standard Hugging Face path instead.
